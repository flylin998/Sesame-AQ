package io.github.aoguai.sesameag.task.customTasks

/**
 * 庄园子任务枚举
 */
enum class CustomTask(val displayName: String) {
    FOREST_WHACK_MOLE("森林打地鼠"),
    FOREST_ENERGY_RAIN("能量雨"),
    FARM_SEND_BACK_ANIMAL("遣返小鸡"),
    FARM_GAME_LOGIC("庄园游戏改分"),
    FARM_CHOUCHOULE("庄园抽抽乐"),
    FARM_SPECIAL_FOOD("庄园使用特殊美食"),
    FARM_USE_TOOL("使用庄园道具")
}

